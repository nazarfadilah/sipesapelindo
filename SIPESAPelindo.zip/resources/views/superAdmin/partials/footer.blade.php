<!-- Super Admin Footer -->
<footer class="app-footer w-100" style="background-color: #1E3F8C">
    <div class="w-100 text-center py-2">
        <p class="mb-0 text-white">© 2025 Pelindo Subregional Banjarmasin - Aplikasi Pengelolaan Sampah</p>
    </div>
</footer>