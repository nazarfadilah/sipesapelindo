<footer class="app-footer">
    <div class="container-fluid text-center py-3">
        <p class="mb-0">© 2025 Pelindo Subregional Banjarmasin - Aplikasi Pengelolaan Sampah</p>
    </div>
</footer>